% Copyright Pieter Abbeel
%
% 5 SLAM
%
%

clear; clc; close all;

%load good_world;

load simple_world_path3;
%load rooms_world_path1;
%load rooms_world_path2;
%load loops_world_path1;
%load loops_world_path2;


T = size(z,2);

% visualize true path

figure; axis equal; hold on;
draw_gridworld(gridworld);
plot(x(1,:), x(2,:), 'x-');

[m,n] = size(gridworld);
x_max_map = 2*max(m,n); y_max_map= 2*max(m,n);

xinit = [x_max_map/2; y_max_map/2; pi/2];

T = size(z,2);
	
map_resolution = 0.25;

m_map = x_max_map / map_resolution;
n_map = y_max_map / map_resolution;

% lf:
lf_xy_res = [0.25; 0.25]; %[0.25; 0.25];
lf_p_hit = 0.95;
lf_p_uniform = 0.05;
lf_z_max = 20;
lf_sigma = laser_model.sigma_hit*10; %to make it a bit smoother


% p5.2: Motion Model Proposal, No Resampling
%  
% This can be slow.  For purpose of assignment OK to just run over a small number of time-steps to
% illustrate the concept.
% OK to try out just one of likelihood field model or laser beam sensor model.
%


n_particles = 5;
weights = 1/n_particles*ones(1,n_particles);

particles = repmat(xinit, 1, n_particles);

init_map{1} = zeros(m_map, n_map);
init_map{2} = zeros(m_map, n_map);
init_map{1}(:,:) = 1; init_map{2}(:,:) = 1;
for i=1:n_particles
	maps{i} = init_map;
end


% YOUR code here


% plot final set of particles/maps:

for i=1:n_particles
	new_fig_flag = 1;
	visualize_ref_map(maps{i}, map_resolution, map_resolution, new_fig_flag);
	title(['weight = ' num2str(log(weights(i)))]);
end





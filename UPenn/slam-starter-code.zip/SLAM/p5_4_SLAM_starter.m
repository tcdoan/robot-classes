% Copyright Pieter Abbeel
%
% 5 SLAM
%
%

% same as 5.3 but use a better proposal distribution (e.g., as in gMapping)
% 
% OK to run over small number of time steps, discuss performance relative
% to 5.2, 5.3 
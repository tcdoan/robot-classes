% Copyright Pieter Abbeel
%
% 5 SLAM
%
%

% same as 5.2 but perform resampling 
% 
% OK to run over small number of time steps, discuss performance relative
% to 5.2 